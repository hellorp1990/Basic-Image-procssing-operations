#ifndef CORE_H
#define CORE_H

#include "image/image.h"
#include "video/video.h"
#include "utility/utility.h"
#include "smoothingtwo/smoothingtwo.h"
#include "smoothingone/smoothingone.h"
#include "incremental/incremental.h"
#include "uniform/uniform.h"
#include "roi/roi.h"
#include "binarize/binarize.h"
#include "scale/scale.h"
#include "scaledown/scaledown.h"
#include "rgb2binary/rgb2binary.h"
#include "hsi/hsi.h"
#include "hsi2rgb/hsi2rgb.h"
#include "stretching/stretching.h"
#include "histogram/histogram.h"
#include "hsi2/hsi2.h"
#include "histogram2/histogram2.h"
#include "stretching2/stretching2.h"
#include "hsihisto/hsihisto.h"
#include "sobel/sobel.h"
#include "prewitt/prewitt.h"
#include "robert/robert.h"
#include "sobel2/sobel2.h"
#include "sobel3/sobel3.h"
#include "sobel4/sobel4.h"
#include "sobel5/sobel5.h"

#endif



