#ifndef SOBEL4_H
#define SOBEL4_H

#include "../image/image.h"
#include <sstream>

class sobel4
{
	public:
		sobel4();
		virtual ~sobel4();
		//static std::string intToString(int number);
		//static int smooth2D(image &src, image &tgt, int value);
				//static int addGrey(image &src, image &tgt,  int value);

                  static int hsisobel1(image &src, image &tgt1,image &tgt2,vector<string> &roivalues);
};

#endif
