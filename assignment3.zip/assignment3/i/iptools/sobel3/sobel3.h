#ifndef SOBEL3_H
#define SOBEL3_H

#include "../image/image.h"
#include <sstream>

class sobel3
{
	public:
		sobel3();
		virtual ~sobel3();
		//static std::string intToString(int number);
		//static int smooth2D(image &src, image &tgt, int value);
				//static int addGrey(image &src, image &tgt,  int value);

                  static int hsisobel(image &src, image &tgt1,image &tgt2,vector<string> &roivalues);
};

#endif
