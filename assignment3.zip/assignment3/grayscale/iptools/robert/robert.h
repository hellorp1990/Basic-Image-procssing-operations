#ifndef ROBERT_H
#define ROBERT_H

#include "../image/image.h"
#include <sstream>

class robert
{
	public:
		robert();
		virtual ~robert();
		//static std::string intToString(int number);
		//static int smooth2D(image &src, image &tgt, int value);
				//static int addGrey(image &src, image &tgt,  int value);

                  static int robertedge(image &src, image &tgt1,image &tgt2,image &tgt3,vector<string> &roivalues);
};

#endif
