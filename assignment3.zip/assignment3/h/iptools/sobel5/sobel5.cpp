//for i


#include "sobel5.h"
#include <stdio.h>
#include<math.h>


/*-----------------------------------------------------------------------**/

void RGBToHSI(int R, int G, int B, double &H, double &S, double &I)
{

    I = (double)(R + G + B) / (double)3;
    double m = min(R, min(G, B));
    double pi = 3.141;

    if (I == 0)
    {
        S = 0;
    }
    else if (I > 0)
    {
        S = 1.0 - (m / I);
    }

    if (G >= B)
    {
        if (R == G && G == B)
        {
            H = 0;
        }
        else
        {
            double temp = acos((R - (G / 2.0) - (B / 2.0)) / (sqrt(pow(R, 2) + pow(G, 2) + pow(B, 2) - (R*G) - (R*B) - (G*B))));
            H = (temp * (180.0)) / pi;
        }
    }
    else if (B > G)
    {
        double temp = acos((R - (G / 2.0) - (B / 2.0)) / (sqrt(pow(R, 2) + pow(G, 2) + pow(B, 2) - (R*G) - (R*B) - (G*B))));

        H = 360 - ((temp * (180.0)) / pi);
    }
}


void HSIToRGB(double H, double S, double I, int &R, int &G, int &B)
{
    double pi = 3.141;

    if (H == 0)
    {
        R = I + (2 * I*S);
        G = I - (I*S);
        B = I - (I*S);
    }
    else if (H > 0 && H < 120)
    {
        R = I + I*S*(cos(H*(pi / 180.0)) / cos((pi / 3.0) - H*(pi / 180.0)));
        G = I + I*S*(1.0 - (cos(H*(pi / 180.0)) / cos((pi / 3.0) - H*(pi / 180.0))));
        B = I - I*S;
    }
    else if (H == 120)
    {
        R = I - (I*S);
        G = I + (2 * I*S);
        B = I - (I*S);
    }
    else if (H > 120 && H < 240)
    {
        R = I - I*S;
        G = I + I*S*((cos(H*(pi / 180.0) - (2.0 * pi) / 3.0)) / (cos((pi)-H*(pi / 180.0))));
        B = I + I*S*(1 - ((cos(H*(pi / 180.0) - (2.0 * pi) / 3.0)) / (cos((pi)-H*(pi / 180.0)))));
    }
    else if (H == 240)
    {
        R = I - (I*S);
        G = I - (I*S);
        B = I + (2 * I*S);
    }
    else if (H > 240 && H < 360)
    {
        R = I + (I*S)*(1 - cos(H*(pi / 180.0) - (4.0*pi / 3.0)) / cos((5.0*pi / 3.0) - H*(pi / 180.0)));
        G = I - (I*S);
        B = I + (I*S)*(cos(H*(pi / 180.0) - (4.0*pi / 3.0)) / cos((5.0*pi / 3.0) - H*(pi / 180.0)));
    }
}


int sobel5::hsisobel2(image &src, image &tgt1,image &tgt2,vector<string> &roivalues)

{

int thresh = atoi(roivalues[7].c_str());
    int angle1 = atoi(roivalues[10].c_str());

    int	GX[3][3];
   int	GY[3][3];
int sumXh,sumYh,SUMh;
int sumXs,sumYs,SUMs;
int sumXi,sumYi,SUMi;
  GX[0][0] = -1; GX[0][1] = 0; GX[0][2] = 1;
   GX[1][0] = -2; GX[1][1] = 0; GX[1][2] = 2;
   GX[2][0] = -1; GX[2][1] = 0; GX[2][2] = 1;

   GY[0][0] =  1; GY[0][1] =  2; GY[0][2] =  1;
   GY[1][0] =  0; GY[1][1] =  0; GY[1][2] =  0;
   GY[2][0] = -1; GY[2][1] = -2; GY[2][2] = -1;
    double h,s,i;
    //R,G,B;
    //tgt.copyImage(src);




  /*  for (int i=0; i<src.getNumberOfRows(); i++)
    {
        for (int j=0; j<src.getNumberOfColumns(); j++)
        {
            tgt.setPixel(i,j,0,src.getPixel(i,j,0));
            tgt.setPixel(i,j,1,src.getPixel(i,j,1));
            tgt.setPixel(i,j,2,src.getPixel(i,j,2));


               // fH[tgt.getPixel(i,j,0)]++;
               // fS[tgt.getPixel(i,j,1)]++;
                //fI[tgt.getPixel(i,j,2)]++;

        }
    }
*/


    for (int y=0; y<src.getNumberOfRows(); y++)
     {
		for (int x=0; x<src.getNumberOfColumns(); x++)
        {
        //if(r == 1)
        //{
					int R = src.getPixel(y, x, 0);
					int G = src.getPixel(y, x, 1);
					int B = src.getPixel(y, x, 2);
					RGBToHSI(R,G,B,h,s,i);


           sumXh = 0;
	      sumYh = 0;

           for(int I=0; I<=2; I++)  {
		   for(int J=0; J<=2; J++)  {
                int newxh,newyh;
           newxh=y+I;
           newyh=x+J;
           RGBToHSI(src.getPixel(newxh,newyh,0), src.getPixel(newxh,newyh,1),
                    src.getPixel(newxh,newyh,2), h,s,i);

                sumXh = sumXh + (int)((h)* (GX[I][J]));
                // sumX = sumX + (int)(value* GX[I+1][J+1]);
		   }
	       }


	       for(int I=0; I<=2; I++)  {
		   for(int J=0; J<=2; J++)  {
                int newxh,newyh;
           newxh=y+I;
           newyh=x+J;
                RGBToHSI(src.getPixel(newxh,newyh,0), src.getPixel(newxh,newyh,1),src.getPixel(newxh,newyh,2), h,s,i);

		       sumYh = sumYh + (int)((h)* (GY[I+0][J+0]));
		   }
	       }

    SUMh = abs(sumXh) + abs(sumYh);
   if(SUMh>255) SUMh=255;
             if(SUMh<0) SUMh=0;
                    RGBToHSI(src.getPixel(y,x,0),src.getPixel(y,x,1),src.getPixel(y,x,2),h,s,i);
                    h=SUMh;


            HSIToRGB(SUMh,0,i,R,G,B);

            tgt1.setPixel(y,x,0,R);
            tgt1.setPixel(y,x,1,G);
            tgt1.setPixel(y,x,2,B);
             //tgt.setPixel(y,x,0,tgt.getPixel(y,x,0));

        //}

                  if (SUMh>thresh)
                  {


                SUMh =255;
                  }
             else
             {


                SUMh=0;
             }
 HSIToRGB(SUMh,0,i,R,G,B);

            tgt2.setPixel(y,x,0,R);
            tgt2.setPixel(y,x,1,G);
            tgt2.setPixel(y,x,2,B);

        }
     }

    }
