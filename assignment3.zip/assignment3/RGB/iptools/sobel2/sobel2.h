#ifndef SOBEL2_H
#define SOBEL2_H

#include "../image/image.h"
#include <sstream>

class sobel2
{
	public:
		sobel2();
		virtual ~sobel2();
		//static std::string intToString(int number);
		//static int smooth2D(image &src, image &tgt, int value);
				//static int addGrey(image &src, image &tgt,  int value);

                  static int rgbsobel(image &src, image &tgt1,image &tgt2,image &tgt3,vector<string> &roivalues);
};

#endif
