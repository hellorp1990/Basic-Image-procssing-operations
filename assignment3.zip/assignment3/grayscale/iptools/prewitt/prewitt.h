#ifndef PREWITT_H
#define PREWITT_H

#include "../image/image.h"
#include <sstream>

class prewitt
{
	public:
		prewitt();
		virtual ~prewitt();
		//static std::string intToString(int number);
		//static int smooth2D(image &src, image &tgt, int value);
				//static int addGrey(image &src, image &tgt,  int value);

                  static int prewittedge(image &src, image &tgt1,image &tgt2,image &tgt3,vector<string> &roivalues);
};

#endif
