#ifndef SOBEL5_H
#define SOBEL5_H

#include "../image/image.h"
#include <sstream>

class sobel5
{
	public:
		sobel5();
		virtual ~sobel5();
		//static std::string intToString(int number);
		//static int smooth2D(image &src, image &tgt, int value);
				//static int addGrey(image &src, image &tgt,  int value);

                  static int hsisobel2(image &src, image &tgt1,image &tgt2,vector<string> &roivalues);
};

#endif
