#include "sobel2.h"
#include <stdio.h>
#include<math.h>


/*-----------------------------------------------------------------------**/

int sobel2::rgbsobel(image &src, image &tgt1,image &tgt2,image &tgt3,vector<string> &roivalues)

{

   int thresh = atoi(roivalues[7].c_str());
    int angle1 = atoi(roivalues[10].c_str());

    int	GX[3][3];
   int	GY[3][3];
int sumXr,sumYr,SUMr;
int sumXg,sumYg,SUMg;
int sumXb,sumYb,SUMb;
  GX[0][0] = -1; GX[0][1] = 0; GX[0][2] = 1;
   GX[1][0] = -2; GX[1][1] = 0; GX[1][2] = 2;
   GX[2][0] = -1; GX[2][1] = 0; GX[2][2] = 1;

   GY[0][0] =  1; GY[0][1] =  2; GY[0][2] =  1;
   GY[1][0] =  0; GY[1][1] =  0; GY[1][2] =  0;
   GY[2][0] = -1; GY[2][1] = -2; GY[2][2] = -1;
    int r,g,b;
    //tgt1.copyImage(src);




  /*  for (int i=0; i<src.getNumberOfRows(); i++)
    {
        for (int j=0; j<src.getNumberOfColumns(); j++)
        {
            tgt.setPixel(i,j,0,src.getPixel(i,j,0));
            tgt.setPixel(i,j,1,src.getPixel(i,j,1));
            tgt.setPixel(i,j,2,src.getPixel(i,j,2));


               // fH[tgt.getPixel(i,j,0)]++;
               // fS[tgt.getPixel(i,j,1)]++;
                //fI[tgt.getPixel(i,j,2)]++;

        }
    }
*/
tgt1.copyImage(src);
 int startx= atoi(roivalues[0].c_str());
        int starty= atoi(roivalues[1].c_str());
           int sizex= atoi(roivalues[2].c_str());
        int sizey= atoi(roivalues[5].c_str());


    for (int y=0; y<src.getNumberOfRows(); y++)
     {
		for (int x=0; x<src.getNumberOfColumns(); x++)
        {
        //if(r == 1)
        //{
        if(y>= startx && y<= startx+sizex && x>= starty && x<=starty+sizey)
                        {

            sumXr = 0;
	      sumYr = 0;

           for(int I=0; I<=2; I++)  {
		   for(int J=0; J<=2; J++)  {
                int newxr,newyr;
           newxr=y+I;
           newyr=x+J;
                int valuer =((src.getPixel(newxr,newyr,0)));
                sumXr = sumXr + (int)((valuer)* (GX[I][J]));
                // sumX = sumX + (int)(value* GX[I+1][J+1]);
		   }
	       }


	       for(int I=0; I<=2; I++)  {
		   for(int J=0; J<=2; J++)  {
                int newxr,newyr;
           newxr=y+I;
           newyr=x+J;
                int valuer =((src.getPixel(newxr,newyr,0)));
		       sumYr = sumYr + (int)((valuer)* (GY[I+0][J+0]));
		   }
	       }

SUMr = abs(sumXr) + abs(sumYr);

if(sumXr== 0) continue;

float thetar = atan(sumYr/sumXr);

float degreer = (thetar*180*7)/22;
float angle2r =angle1+10;
float angle3r=angle1-10;


   if(SUMr>255) SUMr=255;
             if(SUMr<0) SUMr=0;
            tgt1.setPixel(y,x,0,SUMr);
             //tgt.setPixel(y,x,0,tgt.getPixel(y,x,0));

        //}
        if( (degreer>angle3r)&&(degreer<angle2r) ){	//if within angle)
						tgt3.setPixel(y,x,255);

                  }
             else
                            tgt3.setPixel(y,x,0);


                  if (tgt1.getPixel(y,x,0)>thresh)
                  {


                tgt2.setPixel(y,x,0,255);
                  }
             else
             {


                tgt2.setPixel(y,x,0,0);
             }



       // if(g == 1)
        //{


            sumXg = 0;
	      sumYg= 0;

           for(int I=0; I<=2; I++)  {
		   for(int J=0; J<=2; J++)  {
                int newxg,newyg;
           newxg=y+I;
           newyg=x+J;
                int valueg =((src.getPixel(newxg,newyg,1)));
                sumXg = sumXg + (int)((valueg)* (GX[I+0][J+0]));
                // sumX = sumX + (int)(value* GX[I+1][J+1]);
		   }
	       }


	       for(int I=0; I<=2; I++)  {
		   for(int J=0; J<=2; J++)  {
                int newxg,newyg;
           newxg=y+I;
           newyg=x+J;
                int valueg =((src.getPixel(newxg,newyg,1)));
		       sumYg = sumYg + (int)((valueg)* (GY[I+0][J+0]));
		   }
	       }

SUMg = abs(sumXg) + abs(sumYg);

if(sumXg== 0) continue;

float thetag= atan(sumYg/sumXg);
float degreeg = (thetag*180*7)/22;
float angle2g =angle1+10;
float angle3g=angle1-10;

  if(SUMg>255) SUMg=255;
             if(SUMg<0) SUMg=0;
             tgt1.setPixel(y,x,1,SUMg);
           //  tgt.setPixel(y,x,1,tgt.getPixel(y,x,1));


             //}


      //  if(b == 1)
        //{
         if( (degreeg>angle3g)&&(degreeg<angle2g) ){	//if within angle)

						tgt3.setPixel(y,x,255);

                  }
             else
                            tgt3.setPixel(y,x,0);


                        if (tgt1.getPixel(y,x,1)>thresh)
                tgt2.setPixel(y,x,1,255);
             else
                tgt2.setPixel(y,x,1,0);


            sumXb= 0;
	      sumYb= 0;

           for(int I=0; I<=2; I++)  {
		   for(int J=0; J<=2; J++)  {
                int newxb,newyb;
           newxb=y+I;
           newyb=x+J;
                int valueb =((src.getPixel(newxb,newyb,2)));
                sumXb = sumXb + (int)((valueb)* (GX[I+0][J+0]));
                // sumX = sumX + (int)(value* GX[I+1][J+1]);
		   }
	       }


	       for(int I=0; I<=2; I++)  {
		   for(int J=0; J<=2; J++)  {
                int newxb,newyb;
           newxb=y+I;
           newyb=x+J;
                int valueb =((src.getPixel(newxb,newyb,2)));
		       sumYb = sumYb + (int)((valueb)* (GY[I+0][J+0]));
		   }
	       }

SUMb = abs(sumXb) + abs(sumYb);
if(sumXb== 0) continue;

float thetab= atan(sumYb/sumXb);
float degreeb = (thetab*180*7)/22;
float angle2b =angle1+10;
float angle3b=angle1-10;


          if(SUMb>255)
            SUMb=255;
             if(SUMb<0)
             SUMb=0;
             tgt1.setPixel(y,x,2,SUMb);
            // tgt.setPixel(y,x,2,tgt.getPixel(y,x,2));





                if( (degreeb>angle3b)&&(degreeb<angle2b) ){	//if within angle)
						tgt3.setPixel(y,x,255);

                  }
             else
                            tgt3.setPixel(y,x,0);


             if (tgt1.getPixel(y,x,2)>thresh)
                tgt2.setPixel(y,x,2,255);
             else
                tgt2.setPixel(y,x,2,0);

//        }



        }
     }
/*
        for (int y=0; y<src.getNumberOfRows(); y++)
     {
		for (int x=0; x<src.getNumberOfColumns(); x++)
        {

            if(r == 1)
            {



            // SUM1= 255-SUM;
             tgt.setPixel(y,x,0,SUMr);

        }

            if(g == 1)
            {



            // SUM1= 255-SUM;
             tgt.setPixel(y,x,1,SUMg);

            if(b == 1)
            {



            // SUM1= 255-SUM;
             tgt.setPixel(y,x,2,SUMb);
            }
        }
    }

*/
     }

    }
