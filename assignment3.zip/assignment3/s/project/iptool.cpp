#include "../iptools/core.h"
#include <strings.h>
#include <stdio.h>
#include<fstream>
#include<cstdlib>
#include<iostream>
#include<string>

using namespace std;

#define MAXLEN 256

void imageprocess (vector<string> &tokens);

void split(vector<string> &tokens, const string &text, char sep) {
  int start = 0, end = 0;
  while ((end = text.find(sep, start)) != string::npos) {
    tokens.push_back(text.substr(start, end - start));
    start = end + 1;
  }
  tokens.push_back(text.substr(start));
}

void imageprocess (vector<string> &tokens)
{
    image src, tgt1,tgt2,tgt3;

    src.read(tokens[0].c_str());
    tgt1.copyImage(src);
    tgt2.copyImage(src);
    tgt3.copyImage(src);


/*
if (strncasecmp(tokens[3].c_str(),"sobelh",MAXLEN)==0) {
cout<< " "<<tokens[2].c_str();
string str;
	fstream file ;
	vector<string> roivalues;
	file.open(tokens[4].c_str());
	getline(file,str);

    split(roivalues,str,' ');
  sobel5::hsisobel2(src,tgt1,tgt2,roivalues);
          roivalues.clear();
          getline(file,str);

    split(roivalues,str,' ');
sobel5::hsisobel2(src,tgt1,tgt2,roivalues);
         roivalues.clear();
          getline(file,str);

    split(roivalues,str,' ');
sobel5::hsisobel2(src,tgt1,tgt2,roivalues);
          roivalues.clear();
          getline(file,str);

    split(roivalues,str,' ');
sobel5::hsisobel2(src,tgt1,tgt2,roivalues);
}
*/
if (strncasecmp(tokens[3].c_str(),"sobels",MAXLEN)==0) {
cout<< " "<<tokens[2].c_str();
string str;
	fstream file ;
	vector<string> roivalues;
	file.open(tokens[4].c_str());
	getline(file,str);

    split(roivalues,str,' ');
  sobel4::hsisobel1(src,tgt1,tgt2,roivalues);
          roivalues.clear();
          getline(file,str);

    split(roivalues,str,' ');
  sobel4::hsisobel1(src,tgt1,tgt2,roivalues);
         roivalues.clear();
          getline(file,str);

    split(roivalues,str,' ');
  sobel4::hsisobel1(src,tgt1,tgt2,roivalues);
          roivalues.clear();
          getline(file,str);

    split(roivalues,str,' ');
  sobel4::hsisobel1(src,tgt1,tgt2,roivalues);

}

/*

if (strncasecmp(tokens[3].c_str(),"sobelhsi",MAXLEN)==0) {
cout<< " "<<tokens[2].c_str();
string str;
	fstream file ;
	vector<string> roivalues;
	file.open(tokens[4].c_str());
	getline(file,str);

    split(roivalues,str,' ');
  sobel3::hsisobel(src,tgt1,tgt2,roivalues);
          roivalues.clear();
          getline(file,str);

    split(roivalues,str,' ');
  sobel3::hsisobel(src,tgt1,tgt2,roivalues);
         roivalues.clear();
          getline(file,str);

    split(roivalues,str,' ');
  sobel3::hsisobel(src,tgt1,tgt2,roivalues);
          roivalues.clear();
          getline(file,str);

    split(roivalues,str,' ');
  sobel3::hsisobel(src,tgt1,tgt2,roivalues);

}



/*

if (strncasecmp(tokens[4].c_str(),"sobelrgb",MAXLEN)==0) {
cout<< " "<<tokens[4].c_str();
string str;
	fstream file ;
	vector<string> roivalues;
	file.open(tokens[5].c_str());
	getline(file,str);

    split(roivalues,str,' ');
  sobel2::rgbsobel(src,tgt1,tgt2,tgt3,roivalues);
          roivalues.clear();
          getline(file,str);

    split(roivalues,str,' ');
  sobel2::rgbsobel(src,tgt1,tgt2,tgt3,roivalues);
          roivalues.clear();
          getline(file,str);

    split(roivalues,str,' ');
  sobel2::rgbsobel(src,tgt1,tgt2,tgt3,roivalues);
          roivalues.clear();
          getline(file,str);

    split(roivalues,str,' ');
  sobel2::rgbsobel(src,tgt1,tgt2,tgt3,roivalues);
}

/*

if (strncasecmp(tokens[4].c_str(),"edgerobert",MAXLEN)==0) {
string str;
	fstream file ;
	vector<string> roivalues;
	file.open(tokens[5].c_str());
	getline(file,str);

    split(roivalues,str,' ');
  robert::robertedge(src,tgt1,tgt2,tgt3,roivalues);
          roivalues.clear();
          getline(file,str);

    split(roivalues,str,' ');
  robert::robertedge(src,tgt1,tgt2,tgt3,roivalues);
          roivalues.clear();
          getline(file,str);

    split(roivalues,str,' ');
  robert::robertedge(src,tgt1,tgt2,tgt3,roivalues);
          roivalues.clear();
          getline(file,str);

    split(roivalues,str,' ');
  robert::robertedge(src,tgt1,tgt2,tgt3,roivalues);
}





if (strncasecmp(tokens[4].c_str(),"edgeprewitt",MAXLEN)==0) {
cout<< " "<<tokens[4].c_str();
string str;
	fstream file ;
	vector<string> roivalues;
	file.open(tokens[5].c_str());
	getline(file,str);

    split(roivalues,str,' ');
  prewitt::prewittedge(src,tgt1,tgt2,tgt3,roivalues);
          roivalues.clear();
          getline(file,str);

    split(roivalues,str,' ');
prewitt::prewittedge(src,tgt1,tgt2,tgt3,roivalues);
         roivalues.clear();
          getline(file,str);

    split(roivalues,str,' ');
prewitt::prewittedge(src,tgt1,tgt2,tgt3,roivalues);
          roivalues.clear();
          getline(file,str);

    split(roivalues,str,' ');
prewitt::prewittedge(src,tgt1,tgt2,tgt3,roivalues);

}





if (strncasecmp(tokens[4].c_str(),"edgesobel",MAXLEN)==0) {
cout<< " "<<tokens[4].c_str();
string str;
	fstream file ;
	vector<string> roivalues;
	file.open(tokens[5].c_str());
	getline(file,str);

    split(roivalues,str,' ');
  sobel::sobeledge(src,tgt1,tgt2,tgt3,roivalues);
          roivalues.clear();
          getline(file,str);

    split(roivalues,str,' ');
  sobel::sobeledge(src,tgt1,tgt2,tgt3,roivalues);
          roivalues.clear();
          getline(file,str);

    split(roivalues,str,' ');
  sobel::sobeledge(src,tgt1,tgt2,tgt3,roivalues);
          roivalues.clear();
          getline(file,str);

    split(roivalues,str,' ');
  sobel::sobeledge(src,tgt1,tgt2,tgt3,roivalues);

}

/*
if (strncasecmp(tokens[2].c_str(),"hsihistogram",MAXLEN)==0) {
cout<< " "<<tokens[2].c_str();
string str;
	fstream file ;
	vector<string> roivalues;
	file.open(tokens[3].c_str());
	getline(file,str);

    split(roivalues,str,' ');
  hsihisto::hist(src,tgt,roivalues);
          roivalues.clear();

getline(file,str);

    split(roivalues,str,' ');
  hsihisto::hist(src,tgt,roivalues);
          roivalues.clear();
          getline(file,str);

    split(roivalues,str,' ');
  hsihisto::hist(src,tgt,roivalues);
          roivalues.clear();
          getline(file,str);

    split(roivalues,str,' ');
  hsihisto::hist(src,tgt,roivalues);



  }


     if (strncasecmp(tokens[2].c_str(),"change",MAXLEN)==0) {
cout<< " "<<tokens[2].c_str();
string str;
	fstream file ;
	vector<string> roivalues;
	file.open(tokens[3].c_str());
	getline(file,str);

    split(roivalues,str,' ');
  histogram::histo(src,tgt,roivalues);
          roivalues.clear();

getline(file,str);

    split(roivalues,str,' ');
  histogram::histo(src,tgt,roivalues);
          roivalues.clear();
          getline(file,str);

    split(roivalues,str,' ');
  histogram::histo(src,tgt,roivalues);
          roivalues.clear();
          getline(file,str);

    split(roivalues,str,' ');
  histogram::histo(src,tgt,roivalues);



  }

/*
if (strncasecmp(tokens[2].c_str(),"inten",MAXLEN)==0) {
cout<< " "<<tokens[2].c_str();
string str;
	fstream file ;
	vector<string> roivalues;
	file.open(tokens[3].c_str());
	getline(file,str);

    split(roivalues,str,' ');
  stretching::stretch(src,tgt,roivalues);
          roivalues.clear();
          getline(file,str);

    split(roivalues,str,' ');
  stretching::stretch(src,tgt,roivalues);
          roivalues.clear();
          getline(file,str);

    split(roivalues,str,' ');
  stretching::stretch(src,tgt,roivalues);
          roivalues.clear();
          getline(file,str);

    split(roivalues,str,' ');
  stretching::stretch(src,tgt,roivalues);



 }

/*
 if (strncasecmp(tokens[2].c_str(),"inten2",MAXLEN)==0) {
cout<< " "<<tokens[2].c_str();
string str;
	fstream file ;
	vector<string> roivalues;
	file.open(tokens[3].c_str());
	getline(file,str);

    split(roivalues,str,' ');
  stretching2::stretch2(src,tgt,roivalues);
          roivalues.clear();
          getline(file,str);

    split(roivalues,str,' ');
  stretching2::stretch2(src,tgt,roivalues);
          roivalues.clear();
          getline(file,str);

    split(roivalues,str,' ');
  stretching2::stretch2(src,tgt,roivalues);
          roivalues.clear();
          getline(file,str);

    split(roivalues,str,' ');
  stretching2::stretch2(src,tgt,roivalues);



 }


/*
    if (strncasecmp(tokens[2].c_str(),"roithresh",MAXLEN)==0)

  {
     // roi::inroi(src,tgt,atoi(argv[4]));

     cout<< "\n"<<tokens[2].c_str();
        string str;
	fstream file ;
	vector<string> roivalues;
	file.open(tokens[3].c_str());
	getline(file,str);
	cout<< "\n"<<str;
    split(roivalues,str,' ');

      roi::inroi(src,tgt,roivalues);

      roivalues.clear();
      getline(file,str);
	cout<< "\n"<<str;
    split(roivalues,str,' ');

      roi::inroi(src,tgt,roivalues);



      getline(file,str);
	cout<< "\n"<<str;
    split(roivalues,str,' ');

      roi::inroi(src,tgt,roivalues);


      getline(file,str);
	cout<< "\n"<<str;
    split(roivalues,str,' ');

      roi::inroi(src,tgt,roivalues);

  }

    if (strncasecmp(tokens[2].c_str(),"uni",MAXLEN)==0)

  {
     // roi::inroi(src,tgt,atoi(argv[4]));

     cout<< "\n"<<tokens[2].c_str();
        string str;
	fstream file ;
	vector<string> roivalues;
	file.open(tokens[3].c_str());
	getline(file,str);
	cout<< "\n"<<str;

    split(roivalues,str,' ');

     // do binarization
  uniform::uni2D(src,tgt,roivalues);

   roivalues.clear();
      getline(file,str);
	cout<< "\n"<<str;
    split(roivalues,str,' ');
      uniform::uni2D(src,tgt,roivalues);


      roivalues.clear();
      getline(file,str);
	cout<< "\n"<<str;
    split(roivalues,str,' ');
      uniform::uni2D(src,tgt,roivalues);

      roivalues.clear();
      getline(file,str);
	cout<< "\n"<<str;
    split(roivalues,str,' ');
      uniform::uni2D(src,tgt,roivalues);


  }

    if (strncasecmp(tokens[2].c_str(),"increment",MAXLEN)==0)

  {
     // roi::inroi(src,tgt,atoi(argv[4]));

     cout<< "\n"<<tokens[2].c_str();
        string str;
	fstream file ;
	vector<string> roivalues;
	file.open(tokens[3].c_str());
	getline(file,str);
	cout<< "\n"<<str;

    split(roivalues,str,' ');

     // do binarization
    incremental::incre(src,tgt,roivalues);

    roivalues.clear();
      getline(file,str);
	cout<< "\n"<<str;
    split(roivalues,str,' ');
        incremental::incre(src,tgt,roivalues);

        roivalues.clear();
      getline(file,str);
	cout<< "\n"<<str;
    split(roivalues,str,' ');
        incremental::incre(src,tgt,roivalues);

        roivalues.clear();
      getline(file,str);
	cout<< "\n"<<str;
    split(roivalues,str,' ');
        incremental::incre(src,tgt,roivalues);


  }



 if (strncasecmp(tokens[2].c_str(),"smooth1",MAXLEN)==0)
    {

        // do scaling
        //scale::scale2(src,tgt,atoi(argv[4]));

        cout<< "\n"<<tokens[2].c_str();

        string str;
        fstream file ;
        vector<string> roivalues;
        file.open(tokens[3].c_str());
        getline(file,str);
       split(roivalues,str,' ');

        smoothingone::smooth1D(src,tgt,roivalues);
        roivalues.clear();

         getline(file,str);
       split(roivalues,str,' ');

        smoothingone::smooth1D(src,tgt,roivalues);
        roivalues.clear();

 getline(file,str);
       split(roivalues,str,' ');

        smoothingone::smooth1D(src,tgt,roivalues);
        roivalues.clear();
getline(file,str);
       split(roivalues,str,' ');

        smoothingone::smooth1D(src,tgt,roivalues);


  }

   if (strncasecmp(tokens[2].c_str(),"add",MAXLEN)==0) {
cout<< " "<<tokens[2].c_str();
string str;
	fstream file ;
	vector<string> roivalues;
	file.open(tokens[3].c_str());
	getline(file,str);

    split(roivalues,str,' ');
  utility::addg(src,tgt,roivalues);
          roivalues.clear();

          	getline(file,str);

    split(roivalues,str,' ');
  utility::addg(src,tgt,roivalues);
          roivalues.clear();
          	getline(file,str);

    split(roivalues,str,' ');
  utility::addg(src,tgt,roivalues);
          roivalues.clear();
          	getline(file,str);

    split(roivalues,str,' ');
  utility::addg(src,tgt,roivalues);


  }


  if (strncasecmp(tokens[2].c_str(),"smooth",MAXLEN)==0) {
        cout<< "\n"<<tokens[2].c_str();
        string str;
	fstream file ;
	vector<string> roivalues;
	file.open(tokens[3].c_str());
	getline(file,str);
	//cout<< "\n"<<str;

    split(roivalues,str,' ');
    smoothingtwo::smooth2D(src,tgt,roivalues);
            roivalues.clear();
            	getline(file,str);
	//cout<< "\n"<<str;

    split(roivalues,str,' ');
    smoothingtwo::smooth2D(src,tgt,roivalues);
     roivalues.clear();
            	getline(file,str);
	//cout<< "\n"<<str;

    split(roivalues,str,' ');
    smoothingtwo::smooth2D(src,tgt,roivalues);
     roivalues.clear();
            	getline(file,str);
	//cout<< "\n"<<str;

    split(roivalues,str,' ');
    smoothingtwo::smooth2D(src,tgt,roivalues);



  }




 /*
  if (strncasecmp(tokens[2].c_str(),"upscale",MAXLEN)==0) {
cout<< " "<<tokens[2].c_str();
string str;
	fstream file ;
	vector<string> roivalues;
	file.open(tokens[3].c_str());
	getline(file,str);

    split(roivalues,str,' ');
  scale::scale2(src,tgt,roivalues);
       roivalues.clear();

       getline(file,str);

    split(roivalues,str,' ');
  scale::scale2(src,tgt,roivalues);
       roivalues.clear();

       getline(file,str);

    split(roivalues,str,' ');
  scale::scale2(src,tgt,roivalues);
       roivalues.clear();

       getline(file,str);

    split(roivalues,str,' ');
  scale::scale2(src,tgt,roivalues);

  }



   if (strncasecmp(tokens[2].c_str(),"downscale",MAXLEN)==0) {
cout<< " "<<tokens[2].c_str();
string str;
	fstream file ;
	vector<string> roivalues;
	file.open(tokens[3].c_str());
	getline(file,str);

    split(roivalues,str,' ');
  scaledown::down(src,tgt,roivalues);
         roivalues.clear();

	getline(file,str);

    split(roivalues,str,' ');
  scaledown::down(src,tgt,roivalues);
         roivalues.clear();

  	getline(file,str);

    split(roivalues,str,' ');
  scaledown::down(src,tgt,roivalues);
         roivalues.clear();

         	getline(file,str);

    split(roivalues,str,' ');
  scaledown::down(src,tgt,roivalues);

  }

 if (strncasecmp(tokens[2].c_str(),"rgb2bin",MAXLEN)==0) {
cout<< " "<<tokens[2].c_str();
string str;
	fstream file ;
	vector<string> roivalues;
	file.open(tokens[3].c_str());
	getline(file,str);

    split(roivalues,str,' ');
  rgb2binary::convert(src,tgt,roivalues);
           roivalues.clear();
	getline(file,str);

    split(roivalues,str,' ');
  rgb2binary::convert(src,tgt,roivalues);
           roivalues.clear();

	getline(file,str);

    split(roivalues,str,' ');
  rgb2binary::convert(src,tgt,roivalues);
           roivalues.clear();

	getline(file,str);

    split(roivalues,str,' ');
  rgb2binary::convert(src,tgt,roivalues);

  }



   if (strncasecmp(tokens[2].c_str(),"convertrgb",MAXLEN)==0) {
        cout<< "\n"<<tokens[2].c_str();
        string str;
	fstream file ;
	vector<string> roivalues;
	file.open(tokens[3].c_str());
	getline(file,str);
	//cout<< "\n"<<str;

    split(roivalues,str,' ');
    hsi::rgb2hsi(src,tgt,roivalues);
               roivalues.clear();
               getline(file,str);
	//cout<< "\n"<<str;

    split(roivalues,str,' ');
    hsi::rgb2hsi(src,tgt,roivalues);
               roivalues.clear();

getline(file,str);
	//cout<< "\n"<<str;

    split(roivalues,str,' ');
    hsi::rgb2hsi(src,tgt,roivalues);
               roivalues.clear();

getline(file,str);
	//cout<< "\n"<<str;

    split(roivalues,str,' ');
    hsi::rgb2hsi(src,tgt,roivalues);


   }



   if (strncasecmp(tokens[2].c_str(),"converthsi",MAXLEN)==0) {
        cout<< "\n"<<tokens[2].c_str();
        string str;
	fstream file ;
	vector<string> roivalues;
	file.open(tokens[3].c_str());
	getline(file,str);
	//cout<< "\n"<<str;

    split(roivalues,str,' ');
    hsi2rgb::rgb(src,tgt,roivalues);
                   roivalues.clear();
                   getline(file,str);
	//cout<< "\n"<<str;

    split(roivalues,str,' ');
    hsi2rgb::rgb(src,tgt,roivalues);
                   roivalues.clear();
                   getline(file,str);
	//cout<< "\n"<<str;

    split(roivalues,str,' ');
    hsi2rgb::rgb(src,tgt,roivalues);
                   roivalues.clear();
                   getline(file,str);
	//cout<< "\n"<<str;

    split(roivalues,str,' ');
    hsi2rgb::rgb(src,tgt,roivalues);




   }


if (strncasecmp(tokens[2].c_str(),"convertrgb2",MAXLEN)==0) {
        cout<< "\n"<<tokens[2].c_str();
        string str;
	fstream file ;
	vector<string> roivalues;
	file.open(tokens[3].c_str());
	getline(file,str);
	//cout<< "\n"<<str;

    split(roivalues,str,' ');
    hsi2::rgb2hsi2(src,tgt,roivalues);
               roivalues.clear();
               getline(file,str);
	//cout<< "\n"<<str;

    split(roivalues,str,' ');
    hsi2::rgb2hsi2(src,tgt,roivalues);
               roivalues.clear();

getline(file,str);
	//cout<< "\n"<<str;

    split(roivalues,str,' ');
    hsi2::rgb2hsi2(src,tgt,roivalues);
               roivalues.clear();

getline(file,str);
	//cout<< "\n"<<str;

    split(roivalues,str,' ');
    hsi2::rgb2hsi2(src,tgt,roivalues);


   }

*/

    cout<<" " <<"save" ;
	tgt1.save(tokens[1].c_str());
		tgt2.save(tokens[2].c_str());
			tgt3.save(tokens[3].c_str());
}



int main (int argc, char** argv)
{

	string str;
	fstream file ;
	file.open("image.txt");
	vector<string> tokens;
	getline(file,str);//Add
   split(tokens,str,' ');

imageprocess(tokens);


tokens.clear();

getline(file,str);//smooth2D
split(tokens,str,' ');

cout<< "\n"<<str;
cout<< "\n"<<tokens[2].c_str();
imageprocess(tokens);

tokens.clear();

getline(file,str);//smooth1D
split(tokens,str,' ');

imageprocess(tokens);

tokens.clear();

getline(file,str);//incremental
split(tokens,str,' ');

imageprocess(tokens);

tokens.clear();

getline(file,str);//uniform
split(tokens,str,' ');

imageprocess(tokens);


tokens.clear();

getline(file,str);//roi thresh
split(tokens,str,' ');

imageprocess(tokens);


tokens.clear();

getline(file,str);//bw
split(tokens,str,' ');

imageprocess(tokens);


tokens.clear();

getline(file,str);//scaleup
split(tokens,str,' ');

imageprocess(tokens);


tokens.clear();

getline(file,str);//scaledown
split(tokens,str,' ');

imageprocess(tokens);

	getline(file,str);
split(tokens,str,' ');
imageprocess(tokens);


tokens.clear();

getline(file,str);//rgb
split(tokens,str,' ');

imageprocess(tokens);


}

