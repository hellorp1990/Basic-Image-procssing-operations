#include "prewitt.h"
#include <stdio.h>
#include<math.h>



int prewitt::prewittedge(image &src, image &tgt1,image &tgt2,image &tgt3, vector<string> &roivalues)
{

  int thresh = atoi(roivalues[7].c_str());
    int angle1 = atoi(roivalues[10].c_str());
//tgt.resize(src.getNumberOfRows(),src.getNumberOfColumns());
tgt1.copyImage(src);

	int S[3][3] = {{-1,0,1},{-2,0,2},{-1,0,1}};
	int T[3][3] = {{-1,-2,-1},{0,0,0},{1,2,1}};
	int G1 = 0;
	int G2=0;
	int	GX[3][3];
   int	GY[3][3];
int sumX ;
	      int sumY ;
int SUM,SUM1;
  GX[0][0] = -1; GX[0][1] = 0; GX[0][2] = 1;
   GX[1][0] = -1; GX[1][1] = 0; GX[1][2] = 1;
   GX[2][0] = -1; GX[2][1] = 0; GX[2][2] = 1;

   GY[0][0] =  1; GY[0][1] =  1; GY[0][2] =  1;
   GY[1][0] =  0; GY[1][1] =  0; GY[1][2] =  0;
   GY[2][0] = -1; GY[2][1] = -1; GY[2][2] = -1;
/*
	for(int i = 0; i < 3; i++){
		for(int j = 0; j < 3; j++){
			G1 += S[i][j] * src.getPixel(x-i,y-j);
		}
	}

for(int i = 0; i < 3; i++){	//for each pixel in the kernel
		for(int j = 0; j < 3; j++){
			G2 += T[i][j] * src.getPixel(x-i,y-j);
		}
	}

*/
int startx= atoi(roivalues[0].c_str());
        int starty= atoi(roivalues[1].c_str());
           int sizex= atoi(roivalues[2].c_str());
        int sizey= atoi(roivalues[5].c_str());

for (int y=0; y<src.getNumberOfRows(); y++)
     {
		for (int x=0; x<src.getNumberOfColumns(); x++)
        {
             if(y>= startx && y<= startx+sizex && x>= starty && x<=starty+sizey)
                        {


            sumX = 0;
	      sumY = 0;

           for(int I=0; I<=2; I++)  {
		   for(int J=0; J<=2; J++)  {
                int newx,newy;
           newx=y+I;
           newy=x+J;
                int value =((src.getPixel(newx,newy)));
                sumX = sumX + (int)((value)* (GX[I+0][J+0]));
                // sumX = sumX + (int)(value* GX[I+1][J+1]);
		   }
	       }


	       for(int I=0; I<=2; I++)  {
		   for(int J=0; J<=2; J++)  {
                int newx,newy;
           newx=y+I;
           newy=x+J;
                int value =((src.getPixel(newx,newy)));
		       sumY = sumY + (int)((value)* (GY[I+0][J+0]));
		   }
	       }

SUM = abs(sumX) + abs(sumY);

if(sumX == 0) continue;

float theta = atan(sumY/sumX);

float degree = (theta*180*7)/22;
float angle2 =angle1+10;
float angle3=angle1-10;

if(SUM>255) SUM=255;
             if(SUM<0) SUM=0;
            // SUM1= 255-SUM;
             tgt1.setPixel(y,x,SUM);


       if( (degree>angle3)&&(degree<angle2) ){	//if within angle)
						tgt3.setPixel(y,x,255);

                  }
             else
                            tgt3.setPixel(y,x,0);

           if(tgt1.getPixel(y,x)>thresh)
                tgt2.setPixel(y,x,255);
                else
                tgt2.setPixel(y,x,0);

        }
     }
     }

}



